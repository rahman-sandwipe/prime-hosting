<section class="about-part section-mb-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="about-image"><img class="company" src="images/about/01.jpg" alt="about"><img class="people" src="images/about/02.jpg" alt="about"></div>
            </div>
            <div class="col-lg-6">
                <div class="about-content">
                    <h2 class="section-subtitle">about domhost</h2>
                    <h3 class="section-title"><span>Domhost believes</span>in your right ideas online.</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil nemo, animi maiores saepe debitis libero necessitatibus rerum dolores ex. Nisi eveniet mollitia voluptatum. Error, accusamus repudiandae molestias excepturi beatae similique illo quo provident architecto fugiat.</p>
                    <ul>
                        <li>
                            <h5>2343+</h5>
                            <p>registered users</p>
                        </li>
                        <li>
                            <h5>7685+</h5>
                            <p>currently hosted</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/components/home/about-section.blade.php ENDPATH**/ ?>