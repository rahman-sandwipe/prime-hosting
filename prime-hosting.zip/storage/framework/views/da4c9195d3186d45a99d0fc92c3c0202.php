
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <?php echo $__env->make('frontend.components.home.heroSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php echo $__env->make('frontend.components.home.aboutSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php echo $__env->make('frontend.components.home.serviceSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php echo $__env->make('frontend.components.home.serverSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php echo $__env->make('frontend.components.home.featureSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php echo $__env->make('frontend.components.home.supportSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		

		<section class="call2action-part">
			<div class="container">
				<h2>want to get achieve your ideas online?</h2>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit ncidunt neque atque cum nulla temporibus cupiditate excepturi quibusdam magni beatae mollitia</p>
				<a href="pricing-plan.html" class="btn btn-inline"><i class="fas fa-external-link-alt"></i><span>get started</span></a>
			</div>
		</section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/pages/homePage.blade.php ENDPATH**/ ?>