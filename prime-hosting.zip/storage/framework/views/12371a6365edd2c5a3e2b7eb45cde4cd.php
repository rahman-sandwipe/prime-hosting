<section class="compare-part section-ptb-100 section-mb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2 class="section-subtitle"><?php echo e($attribute->attribute_name); ?></h2>
                    <h3 class="section-title">select <span>hosting plan</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive-lg">
                    <table class="table table-bordered table-hover compare-table">
                        <thead id="hostingPan">
                            <?php if($packages->count()): ?>
                            <tr>
                                <th scope="col">
                                    <div class="compare-image">
                                        <img src="<?php echo e(asset('images/partials/05.png')); ?>" alt="hero">
                                    </div>
                                </th>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="col">
                                    <div class="compare-head">
                                        <h3 class="compare-plan"><?php echo e($package->name); ?></h3>
                                        <h4 class="compare-tagline"><?php echo e($package->description); ?></h4>
                                        <h5 class="compare-price">$ <?php echo e($package->price_monthly); ?><span>/ mo</span></h5>
                                        <h4 class="compare-discount">$ <?php echo e($package->price_yearly); ?><span>/ yr</span></h4>
                                        <a class="compare-purchase" href="<?php echo e(url($package->card_api)); ?>">get now</a>
                                    </div>
                                </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endif; ?>
                        </thead>
                        <tbody class="compare-content">
                            <tr>
                                <th colspan="4">
                                    <h5 class="compare-heading">support features</h5>
                                </th>
                            </tr>
                            <tr>
                                <th>
                                    <div class="compare-group">
                                        <h6 class="compare-title">24/7 live chat</h6>
                                        <p class="compare-tooltip"><i class="fas fa-question-circle"></i><span>Lorem
                                                ipsum dolor sit amet elit Quasi ipsum excepturi magni</span></p>
                                    </div>
                                </th>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <th>
                                    <div class="compare-group">
                                        <h6 class="compare-title">24/7 help desk</h6>
                                        <p class="compare-tooltip"><i class="fas fa-question-circle"></i><span>Lorem
                                                ipsum dolor sit amet elit Quasi ipsum excepturi magni</span></p>
                                    </div>
                                </th>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <th>
                                    <div class="compare-group">
                                        <h6 class="compare-title">instant setup</h6>
                                        <p class="compare-tooltip"><i class="fas fa-question-circle"></i><span>Lorem
                                                ipsum dolor sit amet elit Quasi ipsum excepturi magni</span></p>
                                    </div>
                                </th>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <th>
                                    <div class="compare-group">
                                        <h6 class="compare-title">Transfer Assistance</h6>
                                        <p class="compare-tooltip"><i class="fas fa-question-circle"></i><span>Lorem
                                                ipsum dolor sit amet elit Quasi ipsum excepturi magni</span></p>
                                    </div>
                                </th>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/components/hostings/hostingPlan.blade.php ENDPATH**/ ?>