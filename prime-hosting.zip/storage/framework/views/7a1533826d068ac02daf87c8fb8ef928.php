
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Partias Page</h1>
        <p>This is the content of the Partias page.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/pages/partialsPage.blade.php ENDPATH**/ ?>