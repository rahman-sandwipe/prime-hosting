
<?php $__env->startSection('content'); ?>
<section class="single-banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1>blog list</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(Route('homePage')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">blog list</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<section class="bloglist-part section-ptb-100">
    <div class="container">
        <?php echo $__env->make('components.frontend.blog.filter-section', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('components.frontend.blog.blog-section', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('components.frontend.blog.pagination-section', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/blog-list.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/pages/blogs.blade.php ENDPATH**/ ?>