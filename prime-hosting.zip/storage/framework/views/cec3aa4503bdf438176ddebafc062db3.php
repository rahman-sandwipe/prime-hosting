
<?php $__env->startSection('title', 'Partias Page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('dashboardPage')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Hero Section</li>
                            </ol>
                        </div>
                        <h4 class="page-title">ero Section</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Hero Section</h4>
                            <p class="card-title-category">Hero Section</p>
                        </div>
                        <div class="card-body">
                            <form id="addAttributeForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="addAttrName">Attribute Name</label>
                                    <input type="text" class="form-control" id="addAttrName" name="attribute_name"
                                        required>
                                </div>

                                <button type="submit" class="btn btn-primary btn-block">UPDATE</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/pages/partialPage.blade.php ENDPATH**/ ?>