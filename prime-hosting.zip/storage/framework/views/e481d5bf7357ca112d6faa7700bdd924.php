
<?php $__env->startSection('title', 'SEO (Search Engine Optimization) Settings'); ?>
<?php $__env->startSection('content'); ?>
<section>
    <div class="page-title-box">
        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboardPage')); ?>"><?php echo e(__('Dashboard')); ?></a>
                </li>
                <li class="breadcrumb-item active"><?php echo e(__('SEO (Search Engine Optimization) Settings')); ?></li>
            </ol>
        </div>
        <h4 class="page-title"><?php echo e(__('SEO Settings')); ?></h4>
    </div>
</section>
<section class="mb-4">
    <div class="card">
        <div class="card-header">
            <h4 class="header-title"><?php echo e(__('SEO Settings')); ?></h4>
            <p class="text-muted font-14">
                <?php echo e(__('Configure your SEO settings to improve your website\'s visibility on search engines.')); ?>

            </p>
        </div>
        <div class="card-body">
            <?php echo $__env->make('backend.components.settings.seoSettingsForm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/pages/settings/seoSettingsPage.blade.php ENDPATH**/ ?>