<?php $__env->startSection('title', 'Hostings'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.components.hostings.pageTitle', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('frontend.components.hostings.hostingPlan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('frontend.components.hostings.hostingSupport', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/pages/hostingPage.blade.php ENDPATH**/ ?>