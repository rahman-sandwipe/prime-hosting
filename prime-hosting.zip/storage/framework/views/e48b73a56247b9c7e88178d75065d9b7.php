<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                    <li class="breadcrumb-item active"><?php echo e(__('Hosting Packages')); ?></li>
                </ol>
            </div>
            <h4 class="page-title"><?php echo e(__('Hosting Packages')); ?></h4>
        </div>
    </div>
</div>  <?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/components/packages/packageTitle.blade.php ENDPATH**/ ?>