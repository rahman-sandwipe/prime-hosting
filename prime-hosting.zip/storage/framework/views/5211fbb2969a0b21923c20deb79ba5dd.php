<form action="<?php echo e(route('settingsUpdate')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="mail-configs" value="1">

    <div class="form-group">
        <label for="mailDriver">Mail Driver</label>
        <input type="text" class="form-control" id="mailDriver" name="mail_driver" />
    </div>

    <div class="form-group">
        <label for="mailHost">Mail Host</label>
        <input type="text" class="form-control" id="mailHost" name="mail_host" />
    </div>

    <div class="form-group">
        <label for="mailPort">Mail Port</label>
        <input type="text" class="form-control" id="mailPort" name="mail_port" />
    </div>

    <div class="form-group">
        <label for="mailUsername">Mail Username</label>
        <input type="text" class="form-control" id="mailUsername" name="mail_username" />
    </div>

    <div class="form-group">
        <label for="mailPassword">Mail Password</label>
        <input type="text" class="form-control" id="mailPassword" name="mail_password"  />
    </div>

    <div class="form-group">
        <label for="mailFromName">From Name</label>
        <input type="text" class="form-control" id="mailFromName" name="mail_from_name" />
    </div>

    <div class="form-group">
        <label for="mailFromEmail">From Email</label>
        <input type="email" class="form-control" id="mailFromEmail" name="mail_from_email" />
    </div>

    <button type="submit" class="btn btn-primary btn-block">Save</button>
</form>
<script>
    $(document).ready(function() {
    // Load existing mail configurations safely
    $('#mailDriver').val(<?php echo json_encode($mail->mail_driver ?? 'smtp', 15, 512) ?>);
    $('#mailHost').val(<?php echo json_encode($mail->mail_host ?? '127.0.0.1', 15, 512) ?>);
    $('#mailPort').val(<?php echo json_encode($mail->mail_port ?? '587', 15, 512) ?>);
    $('#mailUsername').val(<?php echo json_encode($mail->mail_username ?? 'N/A', 15, 512) ?>);
    $('#mailPassword').val(<?php echo json_encode($mail->mail_password ?? 'N/A', 15, 512) ?>);
    $('#mailFromName').val(<?php echo json_encode($mail->mail_from_name ?? 'N/A', 15, 512) ?>);
    $('#mailFromEmail').val(<?php echo json_encode($mail->mail_from_email ?? 'N/A', 15, 512) ?>);
    })
</script><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/components/settings/mailConfigsForm.blade.php ENDPATH**/ ?>