
<?php $__env->startSection('title', 'Payment Gateways'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboardPage')); ?>"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                    <li class="breadcrumb-item active"><?php echo e(__('Payment Gateways')); ?></li>
                </ol>
            </div>
            <h4 class="page-title"><?php echo e(__('Payment Gateways')); ?></h4>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title"><?php echo e(__('Payment Gateways')); ?></h4>
                <p class="text-muted font-14">
                    <?php echo e(__('Manage your payment gateways here. Make sure to save changes after updating any configuration.')); ?>

                </p>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('settingsUpdate')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Peyment Geteway Hidden input -->
                    <input type="hidden" name="payment-gateways" value="1">

                    <!-- Peyment Geteway Name -->
                    <div class="form-group">
                        <label for="GetewayName"><?php echo e(__('Geteway Name')); ?></label>
                        <input type="text" id="GetewayName" class="form-control" name="name">
                    </div>

                    <!-- Peyment Geteway Logo -->
                    <div class="form-group row">
                        <div class="col-md-10">
                            <label for="getewayLogo"><?php echo e(__('Geteway Logo')); ?></label>
                            <input type="file" id="getewayLogo" class="form-control"name="logo">
                        </div>
                        <div class="col-md-2">
                            <div class="img-preview2" style="border: 1px solid #ddd; padding: 10px; text-align: center;">
                                <img id="logoPreview" src="<?php echo e(asset('images/partials/default2.jpg')); ?>" alt="Logo Preview" class="img-fluid" width="100" height="50">
                            </div>
                        </div>
                    </div>    
                    <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('Save')); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title"><?php echo e(__('Payment Gateways List')); ?></h4>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th><?php echo e(__('SL')); ?>

                            <th><?php echo e(__('Name')); ?></th>
                            <th><?php echo e(__('Logo')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($geteways->isEmpty()): ?>
                        <tr>
                            <td colspan="3" class="text-center"><?php echo e(__('No payment gateways found.')); ?></td>
                        </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $geteways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($gateway->name); ?></td>
                                <td><img src="<?php echo e(asset($gateway->logo)); ?>" alt="<?php echo e($gateway->name); ?>" width="50"></td>
                                <td>
                                    <!-- Actions can be added here -->
                                    <a href="#" class="btn btn-sm btn-primary"><?php echo e(__('Edit')); ?></a>
                                    <a href="#" class="btn btn-sm btn-danger"><?php echo e(__('Delete')); ?></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        const defaultLogo = 'images/partials/default2.jpg'; // ডিফল্ট ইমেজের লোকেশন
        $('#getewayLogo').on('change', function () {
            const file = this.files[0];
            const $preview = $('#logoPreview');
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    $preview.attr('src', e.target.result);
                };
                reader.readAsDataURL(file);
            } else {
                // যদি ফাইল না থাকে, ডিফল্ট ইমেজ দেখানো হবে
                $preview.attr('src', defaultLogo);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/pages/settings/peymentGetewaysPage.blade.php ENDPATH**/ ?>