<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?> :: <?php echo e(config('app.name')); ?></title>

        <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/fonts/flaticon/flaticon.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/fonts/fontawesome/fontawesome.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/slickslider/slick.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/venobox/venobox.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/niceselect/niceselect.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/bootstrap/bootstrap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/main.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/index.css')); ?>">
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    </head>
    <body class="font-sans text-gray-900 antialiased">
        <?php echo $__env->make('frontend.include.top-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		
        <?php echo $__env->make('frontend.include.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

		<?php echo $__env->yieldContent('content'); ?>

        <!-- Footer -->
        <?php echo $__env->make('frontend.include.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <script src="<?php echo e(asset('frontend/vendor/bootstrap/jquery-1.12.4.min.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/bootstrap/popper.min.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/bootstrap/bootstrap.min.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/slickslider/slick.min.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/slickslider/slick-call.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/venobox/venobox.min.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/venobox/venobox-call.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/vendor/niceselect/niceselect.min.js')); ?>"></script>
		<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
		
		<?php echo $__env->yieldContent('styles'); ?>
    </body>
</html>
<?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/guest.blade.php ENDPATH**/ ?>