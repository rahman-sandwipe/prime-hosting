<div class="left-side-menu">
    <div class="slimscroll-menu">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul class="metismenu" id="side-menu">
                <li>
                    <a href="<?php echo e(route('dashboardPage')); ?>">
                        <i class="fa fa-tachometer-alt"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('usersPage')); ?>">
                        <i class="fa fa-users"></i>
                        <span>Users</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('attributesPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Attributes</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('hostingPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Hosting Packages</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('ordersPage')); ?>">
                        <i class="fe-bar-chart-2"></i>
                        <span> Orders </span>
                    </a>
                </li>
                

                <li>
                    <a href="javascript: void(0);">
                        <i class="fa fa-globe"></i>
                        <span>Settings</span>
                    </a>
                </li>
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->
</div><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/include/left-sidebar.blade.php ENDPATH**/ ?>