<div class="left-side-menu">
    <div class="slimscroll-menu">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul class="metismenu" id="side-menu">
                <li>
                    <a href="<?php echo e(route('dashboardPage')); ?>">
                        <i class="fa fa-tachometer-alt"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('featuresPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Features</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('servicesPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Services</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('serversPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Servers</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('usersPage')); ?>">
                        <i class="fa fa-users"></i>
                        <span>Users</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('attributesPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Attributes</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('hostingPage')); ?>">
                        <i class="fa fa-list"></i>
                        <span>Hosting Packages</span>
                    </a>
                </li>
                <!-- Settings -->
                <li>
                    <a href="javascript: void(0);">
                        <i class="fa fa-cog"></i>
                        <span>Settings </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li>
                            <a href="<?php echo e(route('settingsPage')); ?>?site-settings">Site Settings</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settingsPage')); ?>?contact-infos">Contact Infos</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settingsPage')); ?>?social-links">Social Links</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settingsPage')); ?>?mail-configs">Mail Configs</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settingsPage')); ?>?seo-settings">SEO Settings</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settingsPage')); ?>?payment-gateways">Payment Gateways</a>
                        </li>
                    </ul>
                </li>
                <!-- Partial for the pages settings -->
                <li>
                    <a href="javascript: void(0);">
                        <i class="fa fa-headset"></i>
                        <span>Pages Settings </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li>
                            <a href="<?php echo e(route('pagesList')); ?>?hero-section">Hero Section</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('pagesList')); ?>?about-section">About Section</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('pagesList')); ?>?support-section">Support Section</a>
                        </li>
                    </ul>
                </li>
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->
</div><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/include/left-sidebar.blade.php ENDPATH**/ ?>