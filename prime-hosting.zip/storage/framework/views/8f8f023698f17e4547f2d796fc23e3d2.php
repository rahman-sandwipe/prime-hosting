<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?> :: <?php echo e(config('app.name')); ?></title>

        <!-- App css -->
        <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!-- Include in toastr -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
        <script>
            $(document).ready(function() {
                <?php if(session('success')): ?>
                    toastr.success("<?php echo e(session('success')); ?>");
                <?php elseif(session('error')): ?>
                    toastr.error("<?php echo e(session('error')); ?>");
                <?php endif; ?>
            });
        </script>
        <style>
            .img-preview {
                width: 100px;
                height: 100px;
                overflow: hidden;
                border: 2px solid #ccc;
            }
            .img-preview img {
                max-width: 100%;
                max-height: 100%;
                padding: 1px;
                object-fit: cover;
            }
        </style>
    </head>
    <body>
        <div id="wrapper">
            <?php echo $__env->make('backend.include.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>        
            <?php echo $__env->make('backend.include.left-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="content-page">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('backend.include.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('backend.include.right-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="rightbar-overlay"></div>
        
        <script src="<?php echo e(asset('backend/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/libs/jquery-tabledit/jquery.tabledit.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/js/pages/tabledit.init.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/libs/chart-js/Chart.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/js/pages/dashboard.init.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/app.blade.php ENDPATH**/ ?>