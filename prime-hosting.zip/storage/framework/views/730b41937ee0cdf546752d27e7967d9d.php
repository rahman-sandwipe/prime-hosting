<div class="header-top">
    <div class="container">
        <div class="header-top-content">
            <div class="header-info-group"><a href="#" class="header-info"><i class="fas fa-phone-alt"></i><span>0209-4215-5596</span></a><a href="#" class="header-info"><i class="fas fa-envelope"></i><span>info@domhost.com</span></a><a href="#" class="header-info"><i class="fas fa-comments"></i><span>Live Chatting</span></a></div>
            <div class="header-select-group">
                <div class="header-select">
                    <i class="fas fa-flag"></i>
                    <select class="select">
                        <option value="english" selected>english - USA</option>
                        <option value="bangali">bangali - BD</option>
                        <option value="arabic">arabic - SA</option>
                    </select>
                </div>
                <div class="header-select">
                    <i class="fas fa-globe"></i>
                    <select class="select">
                        <option value="english" selected>doller - $USD</option>
                        <option value="bangali">pound - £GBP</option>
                        <option value="arabic">euro - €EUR</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/include/top-header.blade.php ENDPATH**/ ?>