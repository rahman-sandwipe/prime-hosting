
<?php $__env->startSection('title', 'Support Section'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('dashboardPage')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Support Section</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Support Section</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Support Section</h4>
                        </div>
                        <div class="card-body">
                            <form href="<?php echo e(route('pagesUpdate')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" name="support-section" value="1">
                                <!-- Title Input -->
                                <div class="form-group">
                                    <label for="inputTitle">Title</label>
                                    <input type="text" class="form-control" id="inputTitle" name="title" placeholder="eg: Title">
                                </div>

                                <!-- Description Input -->
                                <div class="form-group">
                                    <label for="inputDescription">Description</label>
                                    <textarea rows="3" class="form-control" id="inputDescription" name="description" placeholder="eg: Description"></textarea>
                                </div>

                                <!-- Phone Input -->
                                <div class="form-group">
                                    <label for="phoneNumber">Contact Number</label>
                                    <input type="number" class="form-control" id="phoneNumber" name="phone" placeholder="eg: 1234567890">
                                </div>

                                <!-- Email Input -->
                                <div class="form-group">
                                    <label for="contactEmail">Contact Email</label>
                                    <input type="email" class="form-control" id="contactEmail" name="email" placeholder="eg: webname@example.com">
                                </div>

                                <!-- Live chat Input -->
                                <div class="form-group">
                                    <label for="liveChat">Live Chat</label>
                                    <input type="text" class="form-control" id="liveChat" name="live_chat_api" placeholder="eg: Live Chat API">
                                </div>

                                <!-- Contact Form Input -->
                                <div class="form-group">
                                    <label for="contactForm">Contact Form</label>
                                    <input type="text" class="form-control" id="contactForm" name="contact_form_api" placeholder="eg: Contact Form API">
                                </div>

                                <!-- Image Preview -->
                                <div class="form-group">
                                    <div class="img-preview">
                                        <!-- Default image or existing image will be shown here -->
                                    </div>
                                </div>

                                <!-- Image Input -->
                                <div class="form-group">
                                    <label for="inputImage">Image</label>
                                    <input type="file" class="form-control" id="inputImage" name="image" accept="image/*">
                                </div>

                                <!-- Submit Button -->
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block">UPDATE</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Image preview functionality
        $('#inputImage').on('change', function () {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    $('.img-preview').html(`<img src="${e.target.result}" width="100" height="100">`);
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
    <script>
        // Set a value for the data-preview
        $(document).ready(function() {
            // Initialize the form with existing data
            $('#inputTitle').val('<?php echo e($data->title ?? "N/A"); ?>');
            $('#inputDescription').val('<?php echo e($data->description ?? "N/A"); ?>');
            $('#phoneNumber').val('<?php echo e($data->phone ?? "N/A"); ?>');
            $('#contactEmail').val('<?php echo e($data->email ?? "N/A"); ?>');
            $('#liveChat').val('<?php echo e($data->live_chat_api ?? "N/A"); ?>');
            $('#contactForm').val('<?php echo e($data->contact_form_api ?? "N/A"); ?>');
            $('.img-preview').html(`<img src="<?php echo e($data->image ?? asset('images/partials/default.jpg')); ?>" width="100" height="100">`);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/backend/pages/supportsPage.blade.php ENDPATH**/ ?>