

<section class="single-banner" id="attributeBox">
    <h1 ><?php echo e($attribute->attribute_name); ?> Packages</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('homePage')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($attribute->attribute_name); ?> Packages</li>
    </ol>
</section>
<?php /**PATH H:\LARAVEL_11\prime-hosting\resources\views/frontend/components/hostings/pageTitle.blade.php ENDPATH**/ ?>