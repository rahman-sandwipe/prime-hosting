<section class="service-part section-mb-95">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2 class="section-subtitle">service provide</h2>
                    <h3 class="section-title">our <span>best service</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-lg-4">
                <div class="service-card">
                    <i class="flaticon-web-hosting"></i>
                    <h4>shared hosting</h4>
                    <p>Lorem ipsum dolor sit amet elit expedita quas eos quos animi Nesciunt veniam voluptatem aliquam assumenda.</p>
                    <a href="shared-hosting.html">know more</a>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="service-card">
                    <i class="flaticon-cloud-network"></i>
                    <h4>cloud hosting</h4>
                    <p>Lorem ipsum dolor sit amet elit expedita quas eos quos animi Nesciunt veniam voluptatem aliquam assumenda.</p>
                    <a href="cloud-hosting.html">know more</a>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="service-card">
                    <i class="flaticon-vps"></i>
                    <h4>VPS hosting</h4>
                    <p>Lorem ipsum dolor sit amet elit expedita quas eos quos animi Nesciunt veniam voluptatem aliquam assumenda.</p>
                    <a href="shared-hosting.html">know more</a>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="service-card">
                    <i class="flaticon-shared-folder"></i>
                    <h4>reseller hosting</h4>
                    <p>Lorem ipsum dolor sit amet elit expedita quas eos quos animi Nesciunt veniam voluptatem aliquam assumenda.</p>
                    <a href="reseller-hosting.html">know more</a>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="service-card">
                    <i class="flaticon-database"></i>
                    <h4>dedicated hosting</h4>
                    <p>Lorem ipsum dolor sit amet elit expedita quas eos quos animi Nesciunt veniam voluptatem aliquam assumenda.</p>
                    <a href="cloud-hosting.html">know more</a>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="service-card">
                    <i class="flaticon-domain"></i>
                    <h4>domain name</h4>
                    <p>Lorem ipsum dolor sit amet elit expedita quas eos quos animi Nesciunt veniam voluptatem aliquam assumenda.</p>
                    <a href="domain-search.html">know more</a>
                </div>
            </div>
        </div>
    </div>
</section>