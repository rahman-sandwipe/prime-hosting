<section class="testi-part">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2 class="section-subtitle">client's feedback</h2>
                    <h3 class="section-title">our <span>testimonials</span></h3>
                </div>
            </div>
        </div>
        <div class="testi-slider slider-arrow">
            <div class="testi-card">
                <i class="fas fa-quote-left"></i>
                <div class="testi-rating"><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a></div>
                <p class="testi-desc">Our best-in-class WordPress solution with additio nal optiz ation to make an running a WooCommerce</p>
                <div class="testi-user">
                    <a href="#"><img src="images/avatar/01.jpg" alt="avatar"></a>
                    <h5>miron mahmud <span>Hechinger</span></h5>
                </div>
            </div>
            <div class="testi-card">
                <i class="fas fa-quote-left"></i>
                <div class="testi-rating"><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a></div>
                <p class="testi-desc">Our best-in-class WordPress solution with additio nal optiz ation to make an running a WooCommerce</p>
                <div class="testi-user">
                    <a href="#"><img src="images/avatar/02.jpg" alt="avatar"></a>
                    <h5>tahmina bonny <span>Hechinger</span></h5>
                </div>
            </div>
            <div class="testi-card">
                <i class="fas fa-quote-left"></i>
                <div class="testi-rating"><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a></div>
                <p class="testi-desc">Our best-in-class WordPress solution with additio nal optiz ation to make an running a WooCommerce</p>
                <div class="testi-user">
                    <a href="#"><img src="images/avatar/03.jpg" alt="avatar"></a>
                    <h5>jane alom <span>Hechinger</span></h5>
                </div>
            </div>
            <div class="testi-card">
                <i class="fas fa-quote-left"></i>
                <div class="testi-rating"><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a><a href="#" class="fas fa-star"></a></div>
                <p class="testi-desc">Our best-in-class WordPress solution with additio nal optiz ation to make an running a WooCommerce</p>
                <div class="testi-user">
                    <a href="#"><img src="images/avatar/04.jpg" alt="avatar"></a>
                    <h5>labonno khan <span>Hechinger</span></h5>
                </div>
            </div>
        </div>
    </div>
</section>