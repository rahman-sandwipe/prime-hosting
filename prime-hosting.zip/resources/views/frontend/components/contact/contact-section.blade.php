
<div class="row">
    <div class="col-md-6 col-lg-4">
        <div class="contact-card">
            <i class="fas fa-location-arrow"></i>
            <h4>head office</h4>
            <p>1Hd- 50, 010 Avenue, NY 90001 United States</p>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="contact-card active">
            <i class="fas fa-phone-alt"></i>
            <h4>phone number</h4>
            <p><a href="#">009-215-5596 <span>(toll free)</span></a><a href="#">009-215-5595</a></p>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="contact-card">
            <i class="fas fa-envelope"></i>
            <h4>Support mail</h4>
            <p><a href="#">contact@example.com</a><a href="#">info@example.com</a></p>
        </div>
    </div>
</div>