

<section class="single-banner" id="attributeBox">
    <h1 >{{ $attribute->attribute_name }} Packages</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('homePage') }}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">{{ $attribute->attribute_name }} Packages</li>
    </ol>
</section>
