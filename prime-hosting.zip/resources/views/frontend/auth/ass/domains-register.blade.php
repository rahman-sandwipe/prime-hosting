@extends('frontend.guest')
@section('title', 'Register Domain')
@section('content')
    
@endsection