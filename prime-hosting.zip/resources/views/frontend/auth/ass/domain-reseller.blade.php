@extends('frontend.guest')
@section('title', 'Reseller Domain')
@section('content')
    
@endsection