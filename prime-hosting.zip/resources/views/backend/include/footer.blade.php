<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                &copy; Abstack theme by <a href="">Coderthemes</a>
            </div>

        </div>
    </div>
</footer>