<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SupportFeature extends Model
{
    //
}
