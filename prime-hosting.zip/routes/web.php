<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\User\HomeController;
use App\Http\Controllers\User\ServerController;
use App\Http\Controllers\User\ServiceController;
use App\Http\Controllers\User\AttributeController;

/**Authenticate Routes */
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\User\HostingPackageController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\User\FeatureController;
use App\Http\Controllers\User\SettingsController;

/* | ---------- |Web Routes| ---------- | */
Route::middleware('guest')->group(function () {
    Route::get('register', [RegisteredUserController::class, 'create'])->name('register');
    Route::post('register', [RegisteredUserController::class, 'store']);

    Route::get('login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('login', [AuthenticatedSessionController::class, 'store']);

    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])->name('password.request');
    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])->name('password.email');

    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])->name('password.reset');
    Route::post('reset-password', [NewPasswordController::class, 'store'])->name('password.store');
});

/* | ---------- |User Home Section| ---------- | */
Route::controller(HomeController::class)->group(function () {
    Route::get('/',                 'homePage')->name('homePage');
    Route::get('/about-section',    'aboutSection');
    Route::get('/hero-section',     'heroSection');
    Route::get('/support-section',  'supportSection');
});

Route::controller(FeatureController::class)->group(function () {
    Route::get('/feature-list',                   'featureList')->name('featureList');
});

// AttributeController
Route::controller(AttributeController::class)->group(function () {
    Route::get('/attribute-list',                   'attributeList')->name('attributeList');
    Route::get('/attribute-details/{attribute}',    'attributeDetails')->name('attributeDetails');
    Route::get('/get-package/{attribute}',          'getPackage')->name('getPackage');
});

Route::controller(HostingPackageController::class)->group(function () {
    Route::get('/hosting-package/{attribute:attribute_slug}', 'hostingPackage')->name('hostingPage');
});

/* | ---------- |Server Section| ---------- | */
Route::controller(ServerController::class)->group(function () {
    Route::get('/server-list',                      'serverList')->name('serverList');
    Route::get('/server-details/{server}',          'serverDetails')->name('serverDetails');
});

/* | ---------- |Service Section| ---------- | */
Route::controller(ServiceController::class)->group(function () {
    Route::get('/service-list',                     'serviceList')->name('serviceList');
    Route::get('/service-details/{service}',        'serviceDetails')->name('serviceDetails');
});

/* | ---------- |Settings Routes| ---------- | */
Route::controller(SettingsController::class)->group(function () {
    Route::get('/contact-infos',            'contactInfosPage')->name('contactInfosPage');
    Route::get('/mail-configs',             'mailConfigsPage')->name('mailConfigsPage');
    Route::get('/seo-settings',             'seoSettingsPage')->name('seoSettingsPage');
    Route::get('/site-settings',            'settingsPage')->name('settingsPage');
    Route::get('/social-links',             'socialLinksPage')->name('socialLinksPage');
    Route::get('/payment-gateways',         'peymentGetewaysPage')->name('peymentGetewaysPage');
});

require __DIR__.'/auth.php';
require __DIR__.'/api.php';
